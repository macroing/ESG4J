/**
 * Provides the Lexer API.
 */
package org.macroing.cel4j.lexer;