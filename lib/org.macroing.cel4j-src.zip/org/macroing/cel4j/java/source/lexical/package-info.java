/**
 * Provides the Java Source Lexical API.
 * <p>
 * This API contains classes and interfaces that models the lexical parts of a Java AST or CST.
 */
package org.macroing.cel4j.java.source.lexical;