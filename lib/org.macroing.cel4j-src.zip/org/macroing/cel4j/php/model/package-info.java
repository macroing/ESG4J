/**
 * Provides the PHP Model API.
 * <p>
 * This API contains classes and interfaces to represent PHP source code in an object-oriented manner.
 */
package org.macroing.cel4j.php.model;