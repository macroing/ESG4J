/**
 * Provides the JSON API.
 * <p>
 * This API contains an object-oriented JSON model, as well as parsing and formatting functionality.
 */
package org.macroing.cel4j.json;