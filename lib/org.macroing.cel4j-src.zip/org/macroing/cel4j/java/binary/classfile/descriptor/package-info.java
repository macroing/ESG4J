/**
 * Provides the Java Binary ClassFile Descriptor API.
 * <p>
 * This API contains classes and interfaces that models descriptors.
 */
package org.macroing.cel4j.java.binary.classfile.descriptor;