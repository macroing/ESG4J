/**
 * Provides the Java Binary ClassFile AttributeInfo API.
 * <p>
 * This API contains classes and interfaces that models various attribute_info structures.
 */
package org.macroing.cel4j.java.binary.classfile.attributeinfo;