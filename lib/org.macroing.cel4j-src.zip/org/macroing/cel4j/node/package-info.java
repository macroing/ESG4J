/**
 * Provides the Node API.
 * <p>
 * This API contains classes and interfaces to represent nodes in graph structures and ways to filter, traverse and transform them.
 */
package org.macroing.cel4j.node;