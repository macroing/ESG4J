/**
 * Provides the Java Binary ClassFile CPInfo API.
 * <p>
 * This API contains classes and interfaces that models various cp_info structures.
 */
package org.macroing.cel4j.java.binary.classfile.cpinfo;