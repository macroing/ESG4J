/**
 * Provides the Java Binary ClassFile Signature API.
 * <p>
 * This API contains classes and interfaces that models signatures.
 */
package org.macroing.cel4j.java.binary.classfile.signature;