/**
 * Provides the PHP Generator API.
 * <p>
 * This API contains classes and interfaces used to generate object-oriented class models from simple definitions.
 */
package org.macroing.cel4j.php.generator;