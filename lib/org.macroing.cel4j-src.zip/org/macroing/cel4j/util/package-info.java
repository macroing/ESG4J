/**
 * Provides the Utilities API.
 * <p>
 * This API contains unrelated functionality used by the library.
 */
package org.macroing.cel4j.util;